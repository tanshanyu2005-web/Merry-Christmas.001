import React, { Suspense, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Loader } from '@react-three/drei';
import Experience from './components/Experience';
import Overlay from './components/Overlay';

const App: React.FC = () => {
  const [assembled, setAssembled] = useState(true);

  return (
    <div className="relative w-full h-screen bg-[#020a08]">
      <Canvas
        shadows
        camera={{ position: [0, 2, 8], fov: 45 }}
        dpr={[1, 2]} 
        gl={{ 
          antialias: false,
          toneMappingExposure: 1.2
        }}
      >
        <Suspense fallback={null}>
          <Experience assembled={assembled} />
        </Suspense>
      </Canvas>
      <Loader 
        containerStyles={{ backgroundColor: '#020a08' }} 
        innerStyles={{ width: '200px', height: '2px', backgroundColor: '#333' }}
        barStyles={{ height: '2px', backgroundColor: '#d4af37' }}
        dataStyles={{ color: '#d4af37', fontFamily: 'Playfair Display', fontSize: '12px' }}
      />
      <Overlay assembled={assembled} setAssembled={setAssembled} />
    </div>
  );
};

export default App;