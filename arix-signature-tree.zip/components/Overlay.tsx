import React, { useState } from 'react';

interface OverlayProps {
  assembled?: boolean;
  setAssembled?: (val: boolean) => void;
}

const Overlay: React.FC<OverlayProps> = ({ assembled = true, setAssembled }) => {
  const [activeTab, setActiveTab] = useState<'story' | 'specs'>('story');

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10 text-[#f0e6d2]">
      {/* Header / Brand */}
      <header className="flex justify-between items-start pointer-events-auto">
        <div className="flex flex-col">
          <h1 className="font-serif text-4xl md:text-6xl text-[#d4af37] tracking-tighter drop-shadow-lg">
            ARIX
          </h1>
          <span className="font-sans text-xs md:text-sm tracking-[0.3em] uppercase opacity-80 mt-1">
            Signature Collection
          </span>
        </div>
        
        <div className="hidden md:flex gap-6 text-sm font-sans tracking-widest text-[#d4af37]">
          <button className="hover:text-white transition-colors duration-300">GALLERY</button>
          <button className="hover:text-white transition-colors duration-300">ABOUT</button>
          <button className="hover:text-white transition-colors duration-300 border-b border-[#d4af37] pb-1">EXPERIENCE</button>
        </div>
      </header>

      {/* Center Content - often empty in 3D views, but maybe a subtle guide */}
      <div className="flex-1 flex items-center justify-end md:justify-start pointer-events-none">
          <div className="w-[1px] h-32 bg-gradient-to-b from-transparent via-[#d4af37] to-transparent opacity-50 hidden md:block ml-4"></div>
      </div>

      {/* Footer / Controls */}
      <footer className="flex flex-col md:flex-row justify-between items-end md:items-end gap-6 pointer-events-auto">
        
        {/* Info Card */}
        <div className="backdrop-blur-sm bg-black/30 border border-[#d4af37]/30 p-6 max-w-md rounded-sm shadow-2xl transition-all hover:bg-black/40 hover:border-[#d4af37]/50">
           <div className="flex gap-4 mb-4 border-b border-[#d4af37]/20 pb-2">
             <button 
               onClick={() => setActiveTab('story')}
               className={`font-serif italic text-lg transition-colors ${activeTab === 'story' ? 'text-[#d4af37]' : 'text-gray-500'}`}
             >
               The Narrative
             </button>
             <button 
                onClick={() => setActiveTab('specs')}
                className={`font-serif italic text-lg transition-colors ${activeTab === 'specs' ? 'text-[#d4af37]' : 'text-gray-500'}`}
             >
               Details
             </button>
           </div>
           
           <div className="min-h-[80px]">
             {activeTab === 'story' ? (
                <p className="font-sans text-sm leading-relaxed text-gray-300 font-light">
                  Inspired by the deep winter forests of the North and the gilded halls of Versailles. 
                  The Arix Tree combines structural elegance with the warmth of pure gold leaf accents.
                </p>
             ) : (
                <ul className="font-sans text-xs leading-relaxed text-gray-300 space-y-2">
                  <li className="flex justify-between"><span>Height</span> <span className="text-[#d4af37]">320cm</span></li>
                  <li className="flex justify-between"><span>Material</span> <span className="text-[#d4af37]">Emerald Composite & 24k Gold</span></li>
                  <li className="flex justify-between"><span>Lighting</span> <span className="text-[#d4af37]">Warm Lumen Core</span></li>
                </ul>
             )}
           </div>
        </div>

        {/* Call to Action */}
        <div className="flex flex-col items-end gap-4">
           {setAssembled && (
             <button 
               onClick={() => setAssembled(!assembled)}
               className="group flex items-center gap-2 border border-[#d4af37] px-4 py-2 text-[#d4af37] text-xs font-sans tracking-widest hover:bg-[#d4af37] hover:text-black transition-all duration-300"
             >
               <span className={`block w-2 h-2 rounded-full ${assembled ? 'bg-[#d4af37] group-hover:bg-black' : 'border border-current'}`}></span>
               {assembled ? 'DECONSTRUCT' : 'ASSEMBLE'}
             </button>
           )}

           <div className="flex flex-col items-end gap-2">
             <p className="text-[10px] tracking-widest opacity-60 uppercase">Drag to Rotate • Scroll to Zoom</p>
             <button className="bg-[#d4af37] text-black font-sans text-xs font-bold tracking-widest px-8 py-4 hover:bg-white transition-colors duration-500 shadow-[0_0_20px_rgba(212,175,55,0.4)]">
               INQUIRE NOW
             </button>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default Overlay;