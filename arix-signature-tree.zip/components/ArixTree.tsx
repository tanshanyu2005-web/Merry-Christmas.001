import React, { useMemo, useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// --- Materials ---
const emeraldMaterial = new THREE.MeshStandardMaterial({
  color: "#034528",
  roughness: 0.25,
  metalness: 0.6,
  envMapIntensity: 1.5,
});

const goldMaterial = new THREE.MeshStandardMaterial({
  color: "#d4af37",
  roughness: 0.15,
  metalness: 1,
  envMapIntensity: 2,
});

const glowingLightMaterial = new THREE.MeshStandardMaterial({
  color: "#fffae0",
  emissive: "#ffb700",
  emissiveIntensity: 4,
  toneMapped: false,
});

// --- Helper Functions ---
const getRandomSpherePoint = (radius: number) => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  return new THREE.Vector3(
    r * Math.sin(phi) * Math.cos(theta),
    r * Math.sin(phi) * Math.sin(theta),
    r * Math.cos(phi)
  );
};

const lerp = (start: number, end: number, t: number) => start * (1 - t) + end * t;

// --- Components ---

/**
 * Handles a group of instances that can morph between two states:
 * 1. Tree State (Formatted)
 * 2. Scattered State (Chaos)
 */
interface MorphingInstancesProps {
  count: number;
  geometry: THREE.BufferGeometry;
  material: THREE.Material;
  assembled: boolean;
  generateData: (i: number) => {
    treePosition: THREE.Vector3;
    treeRotation: THREE.Euler;
    treeScale: THREE.Vector3;
    scatterPosition: THREE.Vector3;
    scatterRotation: THREE.Euler;
    scatterScale: THREE.Vector3;
  };
}

const MorphingInstances: React.FC<MorphingInstancesProps> = ({ 
  count, geometry, material, assembled, generateData 
}) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  
  // Store the dual-state data in refs to avoid re-calculating on render
  const data = useMemo(() => {
    const items = [];
    for (let i = 0; i < count; i++) {
      items.push(generateData(i));
    }
    return items;
  }, [count, generateData]);

  // Animation state (0 = scattered, 1 = assembled)
  const animState = useRef(assembled ? 1 : 0);
  const tempObj = useMemo(() => new THREE.Object3D(), []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smoothly interpolate animation state
    const target = assembled ? 1 : 0;
    // Use a spring-like lerp or simple ease
    const speed = 2.5;
    animState.current = THREE.MathUtils.damp(animState.current, target, speed, delta);
    
    // Optimization: Stop updating if we are settled very close to target (optional, but good for battery)
    // For now, we keep running to allow floating animation

    const t = animState.current;
    const isMoving = Math.abs(t - target) > 0.001;
    
    // Add a gentle float to the scattered state
    const time = state.clock.elapsedTime;

    for (let i = 0; i < count; i++) {
      const d = data[i];

      // Interpolate Position
      const cx = lerp(d.scatterPosition.x, d.treePosition.x, t);
      const cy = lerp(d.scatterPosition.y, d.treePosition.y, t);
      const cz = lerp(d.scatterPosition.z, d.treePosition.z, t);

      // Add float noise when scattered (t near 0)
      const floatInfluence = (1 - t) * 0.5; // Scale of float
      const fx = Math.sin(time * 0.5 + i) * floatInfluence;
      const fy = Math.cos(time * 0.3 + i * 2) * floatInfluence;
      
      tempObj.position.set(cx + fx, cy + fy, cz);

      // Interpolate Rotation (Approximate via lerping Euler angles for simplicity, Quaternions better but heavier setup here)
      // For needles/ornaments random spin is fine
      tempObj.rotation.set(
        lerp(d.scatterRotation.x + time * 0.1, d.treeRotation.x, t),
        lerp(d.scatterRotation.y + time * 0.1, d.treeRotation.y, t),
        lerp(d.scatterRotation.z + time * 0.1, d.treeRotation.z, t)
      );

      // Interpolate Scale
      const sx = lerp(d.scatterScale.x, d.treeScale.x, t);
      const sy = lerp(d.scatterScale.y, d.treeScale.y, t);
      const sz = lerp(d.scatterScale.z, d.treeScale.z, t);
      tempObj.scale.set(sx, sy, sz);

      tempObj.updateMatrix();
      meshRef.current.setMatrixAt(i, tempObj.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh 
      ref={meshRef} 
      args={[geometry, material, count]} 
      castShadow 
      receiveShadow 
    />
  );
};

// --- Specific Implementations ---

const Foliage: React.FC<{ assembled: boolean }> = ({ assembled }) => {
  const count = 2500;
  // Use a simple tetrahedron or cone for needle/shard
  const geometry = useMemo(() => {
    const geo = new THREE.ConeGeometry(0.08, 0.4, 4);
    geo.translate(0, 0.2, 0); // Pivot at base
    return geo;
  }, []);

  const generator = useMemo(() => (i: number) => {
    // Tree Logic: Distributed along cone layers
    const layerCount = 7;
    const layerIndex = i % layerCount; 
    const layerHeight = 0.8;
    const yBase = -0.5 + (layerIndex * layerHeight * 0.9);
    
    // Cone parameters for this layer
    const progress = layerIndex / layerCount;
    const radiusAtY = 1.8 * (1 - progress) + 0.1;
    
    // Random position on this cone shell
    const angle = Math.random() * Math.PI * 2;
    const r = Math.random() * radiusAtY;
    const hOffset = Math.random() * 0.6; // Thickness of branch layer
    
    const treePos = new THREE.Vector3(
      Math.cos(angle) * r,
      yBase + hOffset,
      Math.sin(angle) * r
    );

    // Orient needles outward and slightly up
    const treeRot = new THREE.Euler(
       (Math.random() - 0.5) + 0.5, // Tilt up
       angle, // Face outward
       (Math.random() - 0.5) * 0.5
    );

    const treeScale = new THREE.Vector3(1, 1, 1).multiplyScalar(1 - (progress * 0.4));

    // Scatter Logic
    const scatterPos = getRandomSpherePoint(7).add(new THREE.Vector3(0, 2, 0));
    const scatterRot = new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    const scatterScale = treeScale.clone().multiplyScalar(0.5); // Shrink a bit when scattered

    return { 
      treePosition: treePos, treeRotation: treeRot, treeScale, 
      scatterPosition: scatterPos, scatterRotation: scatterRot, scatterScale 
    };
  }, []);

  return (
    <MorphingInstances 
      count={count} 
      geometry={geometry} 
      material={emeraldMaterial} 
      assembled={assembled} 
      generateData={generator} 
    />
  );
};

const Ornaments: React.FC<{ assembled: boolean, type: 'gold' | 'light' }> = ({ assembled, type }) => {
  const count = type === 'gold' ? 80 : 60;
  const geometry = useMemo(() => new THREE.SphereGeometry(1, 16, 16), []);
  const material = type === 'gold' ? goldMaterial : glowingLightMaterial;

  const generator = useMemo(() => (i: number) => {
    // Spiral distribution
    const t = i / count;
    const angle = t * Math.PI * 15; // many turns
    const y = -1 + t * 4; // Height 
    const radius = 1.8 * (1 - t * 0.8) + 0.1;

    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    
    const treePos = new THREE.Vector3(x, y + Math.random() * 0.2, z);
    const scaleVal = type === 'gold' 
        ? Math.random() * 0.15 + 0.1 
        : Math.random() * 0.08 + 0.05;
    
    const treeScale = new THREE.Vector3(scaleVal, scaleVal, scaleVal);
    const treeRot = new THREE.Euler(0, 0, 0);

    const scatterPos = getRandomSpherePoint(6).add(new THREE.Vector3(0, 1, 0));
    const scatterRot = new THREE.Euler(Math.random(), Math.random(), Math.random());
    const scatterScale = treeScale;

    return { 
        treePosition: treePos, treeRotation: treeRot, treeScale, 
        scatterPosition: scatterPos, scatterRotation: scatterRot, scatterScale 
      };
  }, [count, type]);

  return (
    <MorphingInstances 
      count={count} 
      geometry={geometry} 
      material={material} 
      assembled={assembled} 
      generateData={generator} 
    />
  );
};

const Star: React.FC<{ assembled: boolean }> = ({ assembled }) => {
    const groupRef = useRef<THREE.Group>(null);
    // Just move the whole group
    useFrame((state, delta) => {
        if (!groupRef.current) return;
        const targetPos = assembled ? new THREE.Vector3(0, 4.2, 0) : new THREE.Vector3(0, 6, -2);
        const targetScale = assembled ? 1 : 0.01; // Shrink to nothing or fly away
        
        groupRef.current.position.lerp(targetPos, delta * 2);
        
        // Spin logic
        groupRef.current.rotation.y += delta;
        
        // Manual scale lerp
        const currentScale = groupRef.current.scale.x;
        const newScale = THREE.MathUtils.lerp(currentScale, targetScale, delta * 2);
        groupRef.current.scale.setScalar(newScale);
    });

    return (
        <group ref={groupRef}>
             <mesh material={glowingLightMaterial}>
                <octahedronGeometry args={[0.3, 0]} />
            </mesh>
            <mesh rotation={[0, Math.PI/4, 0]} material={goldMaterial}>
                <octahedronGeometry args={[0.4, 0]} />
            </mesh>
             {/* Rays */}
             <mesh material={goldMaterial} scale={[0.05, 1.2, 0.05]}>
                <boxGeometry />
            </mesh>
            <mesh material={goldMaterial} scale={[0.05, 1.2, 0.05]} rotation={[0, 0, Math.PI/2]}>
                <boxGeometry />
            </mesh>
        </group>
    )
}

const Base: React.FC<{ assembled: boolean }> = ({ assembled }) => {
    const ref = useRef<THREE.Group>(null);
    useFrame((_, delta) => {
        if(!ref.current) return;
        // Move down into ground when scattered
        const targetY = assembled ? -1.2 : -5;
        ref.current.position.y = THREE.MathUtils.lerp(ref.current.position.y, targetY, delta * 2);
    })

    return (
        <group ref={ref}>
            <mesh receiveShadow>
                <cylinderGeometry args={[0.8, 1, 0.5, 32]} />
                <meshStandardMaterial color="#1a1a1a" roughness={0.1} metalness={0.8} />
            </mesh>
            <mesh position={[0, -0.3, 0]} receiveShadow>
                <cylinderGeometry args={[1.2, 1.4, 0.2, 32]} />
                <meshStandardMaterial color="#d4af37" roughness={0.2} metalness={1} />
            </mesh>
        </group>
    )
}

const ArixTree: React.FC<{ assembled: boolean }> = ({ assembled }) => {
  return (
    <group>
      <Base assembled={assembled} />
      <Foliage assembled={assembled} />
      <Ornaments assembled={assembled} type="gold" />
      <Ornaments assembled={assembled} type="light" />
      <Star assembled={assembled} />
    </group>
  );
};

export default ArixTree;