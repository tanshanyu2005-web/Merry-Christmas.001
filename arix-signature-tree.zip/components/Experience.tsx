import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { 
  OrbitControls, 
  Environment, 
  PerspectiveCamera, 
  ContactShadows,
  Float,
  Stars
} from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import * as THREE from 'three';
import ArixTree from './ArixTree';
import FloatingParticles from './FloatingParticles';

interface ExperienceProps {
  assembled: boolean;
}

const Experience: React.FC<ExperienceProps> = ({ assembled }) => {
  const groupRef = useRef<THREE.Group>(null);

  // Slow rotation for the whole showcase
  useFrame((state) => {
    if (groupRef.current) {
      // Rotate slowly, but maybe slow down even more when scattered to appreciate the chaos
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <>
      {/* Cinematic Camera */}
      <PerspectiveCamera makeDefault position={[0, 1.5, 9]} fov={40} />
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 3} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={5}
        maxDistance={15}
        rotateSpeed={0.5}
        dampingFactor={0.05}
      />

      {/* Lighting Setup for Drama */}
      <ambientLight intensity={0.2} color="#001a10" />
      
      {/* Key Light - Warm Gold */}
      <spotLight 
        position={[5, 10, 5]} 
        angle={0.25} 
        penumbra={1} 
        intensity={20} 
        castShadow 
        color="#ffecd1"
        shadow-mapSize={[2048, 2048]}
      />
      
      {/* Rim Light - Cool Blue/Green to separate from background */}
      <spotLight 
        position={[-5, 5, -5]} 
        angle={0.5} 
        penumbra={1} 
        intensity={10} 
        color="#00ffaa" 
      />

      {/* Fill Light - Gold */}
      <pointLight position={[0, -2, 2]} intensity={5} color="#d4af37" distance={10} />

      {/* Environment for Reflections */}
      <Environment preset="city" environmentIntensity={0.5} />

      {/* Scene Content */}
      <group ref={groupRef} position={[0, -1.5, 0]}>
        <ArixTree assembled={assembled} />
        <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
          <FloatingParticles count={150} />
        </Float>
      </group>
      
      {/* Ground Contact Shadow - Fade it out when scattered? keeping it is fine as "ground" */}
      <ContactShadows 
        opacity={0.7} 
        scale={20} 
        blur={2} 
        far={4.5} 
        resolution={512} 
        color="#000000" 
      />

      {/* Background Ambience */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <fog attach="fog" args={['#020a08', 5, 25]} />

      {/* Post Processing for the "Signature" Look */}
      <EffectComposer disableNormalPass>
        {/* Bloom for the glowing gold and lights */}
        <Bloom 
          luminanceThreshold={1.1} // Only very bright things glow
          mipmapBlur 
          intensity={1.2} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        <Noise opacity={0.02} /> 
      </EffectComposer>
    </>
  );
};

export default Experience;